package com.lokesh.helper;

public class Message {
	
	public String content;
	public String type;

	public Message(String content, String type) {
		super();
		this.content = content;
		this.type = type;
	}


}
