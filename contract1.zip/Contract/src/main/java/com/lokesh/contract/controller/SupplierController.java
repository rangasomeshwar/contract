package com.lokesh.contract.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lokesh.contract.entities.Supplier;
import com.lokesh.contract.entities.repos.SupplierRepository;

@Controller
public class SupplierController {
	
	@Autowired
	private SupplierRepository supplierRepository;
	
	@RequestMapping("/showReg")
	public String showRolePage() {
		return "login/home";
	}
	
	@RequestMapping(value="/adminLoginPage")
	public String showAdminLoginPage() {
		return "login/adminlogin";
	}
	
	@RequestMapping(value="/supplierLoginPage1")
	public String showSupplierPage() {
	
		return "login/registerOrLogin";
	}

	
	@RequestMapping(value="/supplierLoginPage")
	public String showSupplierRegisterPage() {
	
		return "login/registerUser";
	}
	
	@RequestMapping(value="/loginPage")
	public String showSupplierLoginPage() {
	
		return "login/login";
	}
	
	@RequestMapping(value="registerUser", method=RequestMethod.POST)
	public String register(@ModelAttribute("user") Supplier supplier) {
	supplierRepository.save(supplier);
		return "login/login" ;
		
	}
	
	@RequestMapping(value="login", method=RequestMethod.POST)
	public String login(@RequestParam("email") String email, @RequestParam("password") String password, ModelMap modelMap) {
		
		Supplier supplier = supplierRepository.findByEmail(email);
		if(supplier.getPassword().equals(password)) {
			return "login/viewRequirement";
			
		}else {
			modelMap.addAttribute("msg","invalid login details");
		}
		return "login/invalidLogin";
	}

}
