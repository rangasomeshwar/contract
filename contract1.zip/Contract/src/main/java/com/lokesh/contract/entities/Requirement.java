package com.lokesh.contract.entities;

import java.security.Timestamp;
import java.sql.Date;

import javax.persistence.Entity;

@Entity
public class Requirement extends AbstractEntity {
	
	private String requirementId;
	private String requirementType;
	private String requirementDescription;
	private Date expectedDelivery;
	public String getRequirementId() {
		return requirementId;
	}
	public void setRequirementId(String requirementId) {
		this.requirementId = requirementId;
	}
	public String getRequirementType() {
		return requirementType;
	}
	public void setRequirementType(String requirementType) {
		this.requirementType = requirementType;
	}
	public String getRequirementDescription() {
		return requirementDescription;
	}
	public void setRequirementDescription(String requirementDescription) {
		this.requirementDescription = requirementDescription;
	}
	public Date getExpectedDelivery() {
		return expectedDelivery;
	}
	public void setExpectedDelivery(Date expectedDelivery) {
		this.expectedDelivery = expectedDelivery;
	}
	
	

}
