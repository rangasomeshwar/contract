package com.lokesh.contract.entities.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lokesh.contract.entities.Requirement;

public interface RequirementRepository extends JpaRepository<Requirement, Long> {

}
