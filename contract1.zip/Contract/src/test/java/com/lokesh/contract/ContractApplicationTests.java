package com.lokesh.contract;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContractApplicationTests {

	@Test
	void contextLoads() {
	}

}
